package io.cloudNativeData.sql.task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqlTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
