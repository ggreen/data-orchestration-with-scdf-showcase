package io.cloudNativeData.sql.task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqlTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(SqlTaskApplication.class, args);
	}

}
